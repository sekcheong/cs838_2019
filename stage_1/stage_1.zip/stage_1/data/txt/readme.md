This directory contains all the text files with person entity marked in `<N></N>` tags. For example: `"Mr. <N>Tony Blair</N> said..."` or `"<N>Simpson</N> has been wanting to quit the band..."`.
